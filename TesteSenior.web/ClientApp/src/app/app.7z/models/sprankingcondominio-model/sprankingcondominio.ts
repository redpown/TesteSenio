export class SPRankingCondominio {
  public codigoApartamento: number = 0;
  public codigoEdificio: number = 0;
  public nomeEdificio: string ="";
  public metragem: number = 0;
  public andar: number = 0;
  public numeroQuartos: number = 0;
  public nomeCidade: string="";
  public estado: string = "";
  public valorPagamento: number = 0;
  
  }
