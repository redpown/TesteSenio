export class Generic {
  public id: number = 0;
  public descricao: string ="";

   public  Limpar(){
     this.id = 0;
     this.descricao = "";
      
    }
  }
