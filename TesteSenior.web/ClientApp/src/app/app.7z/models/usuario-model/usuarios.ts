export class Usuarios {
  public email: string = "";
  public senha: string = "";
  public perfil: number = 0;


   public  Limpar(){
     this.email = "";
     this.senha = "";

    }
  }
