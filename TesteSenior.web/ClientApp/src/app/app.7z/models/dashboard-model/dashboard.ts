export class Dashboard {
  public total: number = 0;
  public tipo: string = "";
  public status: string = "";
  public coleta: string = "";
  public exame: string = "";
  public mes: string = "";
  public ano: number = 0;

}
