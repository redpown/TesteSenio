export class Edificio {
  public codigoEdificio:number = 0;
  public nomeCidade: string = "";
  public estado: string = "";
  public nomeEdificio: string = "";
  public andares: number = 0;
  public numeroAptoAndar: number = 0;
  }
