export class QualidadeMetricas {
  public qmId: number = 0;
  public qmTotal: number = 0;
  public qmExameId: number = 0;
  public qmQuantidade: number = 0;
  public qmColetaId: number = 0;
  public qmTipoExame: number = 0;
  public qmExameStatusId: number = 0;
  public qmData?: string ="";
  public Limpar() {
    /*this.codigoCidade = 0;
    this.nomeCidade = "";
    this.estado = "";*/
  }
}
