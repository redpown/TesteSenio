import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Title } from "@angular/platform-browser";
import { Usuarios } from '../models/usuario-model/usuarios';
import { StorageService } from '../services/localStorage-service/localStorage.services';

@Component({
  selector: 'app-user-login',
  templateUrl: './login.component.html'
})
export class UserLoginComponent implements OnInit {
  
  public constructor(private titleService: Title, private router: Router, private storageService: StorageService) { }
  public usuario: Usuarios = new Usuarios();
  logar(): void {

    //localStorage.setItem('Logado', 'true');
    //sessionStorage.setItem('Logado', 'true');
    //localStorage.setItem('perfil', 'true');
    
    //recuperar localStorage.getItem('dados') ou  sessionStorage.getItem('Logado');
    //console.log(sessionStorage.getItem('Logado'));
    this.router.navigateByUrl("metricas-de-qualidade");
    this.storageService.set("perfil", "true");
    this.storageService.set("isLogado", "true");
  }



  ngOnInit() {

    //this.storageService.clear();
    this.titleService.setTitle("Eme - Login");


  }
}
