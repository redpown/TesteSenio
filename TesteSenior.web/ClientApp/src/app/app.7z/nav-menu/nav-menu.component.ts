import { Component, OnInit } from '@angular/core';
import { StorageService } from '../services/localStorage-service/localStorage.services';

@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrls: ['./nav-menu.component.css']
})
export class NavMenuComponent implements OnInit  {
  isExpanded = false;
  

  constructor(private storageService: StorageService) { }
  currentPerfil: string = "";
  isLogado: string = "";
  numA:number = 1;
  numB:number = 2;

  collapse() {
   
    this.isExpanded = false;
  }
  ngOnInit() {


    this.currentPerfil = this.storageService.get("perfil");
    this.isLogado = this.storageService.get("isLogado");
    console.log("nave Data Storage nave: ");
    console.log(this.storageService.get("perfil"));
    console.log("nave Data Storage isLogado nave: ");
    console.log(this.storageService.get("isLogado"));
  }

  toggle() {
    this.isExpanded = !this.isExpanded;
  }
}
