import { ReturnStatement } from '@angular/compiler';
import { Component, OnInit, } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { Dashboard } from '../models/dashboard-model/dashboard';
import { DashboardService } from '../services/dashboard/dashboard.services';

@Component({
  selector: 'app-dashboard-component',
  templateUrl: './dashboard.component.html',
 
})


export  class DashBoardComponent implements OnInit {

//tutorial from https://www.positronx.io/angular-chart-js-tutorial-with-ng2-charts-examples/
//npm install ng2-charts chart.js --save
 // dasboard variavesis
  public lineBigDashboardChartType: any;
  public gradientStroke: any;
  public chartColor: any;
  public canvas: any;
  public ctx: any;
  public gradientFill: any;
  public lineBigDashboardChartData: Array<any> = [];
  public lineBigDashboardChartOptions: any;
  public lineBigDashboardChartLabels: Array<any> = [];
  public lineBigDashboardChartColors: Array<any> = [];

  public gradientChartOptionsConfiguration: any;
  public gradientChartOptionsConfigurationWithNumbersAndGrid: any;

  public lineChartType: any;
  public lineChartData: Array<any> = [];
  public lineChartOptions: any;
  public lineChartLabels: Array<any> = [];
  public lineChartColors: Array<any> = [];

  public lineChartWithNumbersAndGridType: any;
  public lineChartWithNumbersAndGridData: Array<any> = [];
  public lineChartWithNumbersAndGridOptions: any;
  public lineChartWithNumbersAndGridLabels: Array<any> = [];
  public lineChartWithNumbersAndGridColors: Array<any> = [];

  public lineChartGradientsNumbersType: any;
  public lineChartGradientsNumbersData: Array<any> = [];
  public lineChartGradientsNumbersOptions: any;
  public lineChartGradientsNumbersLabels: Array<any> = [];
  public lineChartGradientsNumbersColors: Array<any> = [];
  // events
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }
  public acidoUrico: Dashboard[] = [];
  public creatinina: Dashboard[] =  [];
  public hemograma: Dashboard[] = [];
  public HIV: Dashboard[] = [];
  public LDH: Dashboard[] = [];
  public ureia: Dashboard[] = [];
  public urina1: Dashboard[] = [];
  public mensagem: string = "";



  constructor(private router: Router,
    private activatedRouter: ActivatedRoute,
    private dashboardService: DashboardService) {

  }

ngOnInit() {
  
  this.carregarDashboard();
  //se precsio esperar um retorno assincrono, colocar um funcao entro do subscribe
  this.setDatas();


  this.lineChartOptions = {
    responsive: true,
    layout: {
      padding: {
        left: 20,
        right: 20,
        top: 0,
        bottom: 0
      }
    },
    maintainAspectRatio: false,
    tooltips: {
      backgroundColor: '#fff',
      titleFontColor: '#333',
      bodyFontColor: '#666',
      bodySpacing: 4,
      xPadding: 12,
      mode: "nearest",
      intersect: 0,
      position: "nearest"
    },
    legend: {
      position: "bottom",
      fillStyle: "#FFF",
      display: true
    },
    scales: {
      yAxes: [{
        ticks: {
          fontColor: "rgba(0,0,0,0.4)",
          fontStyle: "bold",
          beginAtZero: true,
          maxTicksLimit: 5,
          padding: 10
        },
        gridLines: {
          drawTicks: true,
          drawBorder: true,
          display: true,
          color: "rgba(0,0,0,0.1)",
          zeroLineColor: "transparent"
        }

      }],
      xAxes: [{
        gridLines: {
          drawTicks: true,
          drawBorder: true,
          display: true,
          color: "rgba(0,0,0,0.1)",
          zeroLineColor: "transparent"

        },
        ticks: {
          padding: 10,
          fontColor: "rgba(0,0,0,0.4)",
          fontStyle: "bold"
        }
      }]
    }
  };
  
  }




  
  public lineChartDatas: ChartDataSets[] = [
  { data: [85, 72, 78, 75, 77, 75], label: 'Exame 01' }
 
  
];

  public meses: string[] = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
  public linesChartLabels: Label[] = ['January', 'February', 'March', 'April', 'May', 'June', 'July','AGoste','Setembre','Outubro','Novembro','Dezembro'];
  public valores: number[] = [];

linesChartOptions = {
  responsive: true,
};
//cores
public linesChartColors: Color[] = [
  {
    borderColor: 'rgb(0, 83, 225)',
    backgroundColor: 'rgba(225, 225, 225,1)',
  },
  {
    borderColor: 'rgb(255, 8, 9)',
    backgroundColor: 'rgba(225, 225, 225,1)',
  },
  {
    borderColor: 'rgb(255, 8, 255)',
    backgroundColor: 'rgba(225, 225, 225,1)',
  },
  {
    borderColor: 'rgb(0, 194, 19)',
    backgroundColor: 'rgba(225, 225, 225,1)',
  },
  {
    borderColor: 'rgb(255, 160, 9)',
    backgroundColor: 'rgba(225, 225, 225,1)',
  },
  {
    borderColor: 'rgb(0, 225, 225)',
    backgroundColor: 'rgba(225, 225, 225,1)',
  },
  {
    borderColor: 'rgb(249, 255, 0)',
    backgroundColor: 'rgba(225, 225, 225,1)',
  },
  {
    borderColor: 'rgb(148, 1, 130)',
    backgroundColor: 'rgba(225, 225, 225,1)',
  }
];

lineChartLegend = true;
lineChartPlugins = [];
linesChartType: ChartType = "line";

setDatas(){

 // this.lineChartLabels.includes(this.meses);
 // this.lineChartData.push({ data: [105, 102, 108, 105, 107, 105], label: 'Exame 10' });

  //console.log(this.creatinina[0].mes);

  }
  


  carregarDashboard() {

     this.dashboardService.GetAllHemograma()
      .subscribe(
        getJson => {
          //se precsio esperar um retorno assincrono, colocar um funcao entro do subscribe
          this.hemograma = getJson;
          this.CarregarDadosDashboard(this.hemograma);
       
         
        },
        err => {
          console.log(err.error);
          this.mensagem = err.error;

        }
    );

    this.dashboardService.GetAllCreatinina()
      .subscribe(
        getJson => {
          //se precsio esperar um retorno assincrono, colocar um funcao entro do subscribe
          this.creatinina = getJson;
          this.CarregarDadosDashboard(this.creatinina);

         
        },
        err => {
          console.log(err.error);
          this.mensagem = err.error;

        }

    );

    this.dashboardService.GetAllAcidoUrico()
      .subscribe(
        getJson => {
          //se precsio esperar um retorno assincrono, colocar um funcao entro do subscribe
          this.acidoUrico = getJson;
          this.CarregarDadosDashboard(this.acidoUrico);

        },
        err => {
          console.log(err.error);
          this.mensagem = err.error;

        }
    );

    this.dashboardService.GetAllUrina1()
      .subscribe(
        getJson => {
          //se precsio esperar um retorno assincrono, colocar um funcao entro do subscribe
          this.urina1 = getJson;
          this.CarregarDadosDashboard(this.urina1);


        },
        err => {
          console.log(err.error);
          this.mensagem = err.error;

        }
    );

    this.dashboardService.GetAllUreia()
      .subscribe(
        getJson => {
          //se precsio esperar um retorno assincrono, colocar um funcao entro do subscribe
          this.ureia = getJson;
          this.CarregarDadosDashboard(this.ureia);

        
        },
        err => {
          console.log(err.error);
          this.mensagem = err.error;

        }
    );

    this.dashboardService.GetAllLDH()
      .subscribe(
        getJson => {
          //se precsio esperar um retorno assincrono, colocar um funcao entro do subscribe
          this.LDH = getJson;
          this.CarregarDadosDashboard(this.LDH);

        },
        err => {
          console.log(err.error);
          this.mensagem = err.error;

        }
    );

    this.dashboardService.GetAllHIV()
      .subscribe(
        getJson => {
          //se precsio esperar um retorno assincrono, colocar um funcao entro do subscribe
          this.HIV = getJson;
          this.CarregarDadosDashboard(this.HIV);

     
        },
        err => {
          console.log(err.error);
          this.mensagem = err.error;

        }
    );
   

    
   
  }
  CarregarDadosDashboard(obj:Dashboard[]) {
    let val:number[]= [];
    obj.forEach((dado) => {
      if (dado.ano == 2020) {
        //  this.lineChartLabels.push(dado.mes + " - " + dado.ano);
        val.push(dado.total);
      }
    });

    this.linesChartColors = [
      {
        borderColor: 'rgb(0, 83, 225)',
        backgroundColor: 'rgba(0, 83, 225,1)',
      },
      {
        borderColor: 'rgb(255, 8, 9)',
        backgroundColor: 'rgba(255, 8, 9,1)',
      },
      {
        borderColor: 'rgb(255, 8, 255)',
        backgroundColor: 'rgba(255, 8, 255,1)',
      },
      {
        borderColor: 'rgb(0, 194, 19)',
        backgroundColor: 'rgba(0, 194, 19,1)',
      },
      {
        borderColor: 'rgb(255, 160, 9)',
        backgroundColor: 'rgba(255, 160, 9,1)',
      },
      {
        borderColor: 'rgb(0, 225, 225)',
        backgroundColor: 'rgba(0, 225, 225,1)',
      },
      {
        borderColor: 'rgb(249, 255, 0)',
        backgroundColor: 'rgba(249, 255, 0,1)',
      },
      {
        borderColor: 'rgb(148, 1, 130)',
        backgroundColor: 'rgba(148, 1, 130,1)',
      }
    ];


    //this.lineChartColors.push({
    //  borderColor: 'rgb(0, 83, 225)',
    //  backgroundColor: 'rgba(225, 225, 225,1)',
    //});
    this.lineChartDatas.push({
      label: obj[0].exame,
      pointBorderWidth: 1,
      pointHoverRadius: 7,
      pointHoverBorderWidth: 2,
      pointRadius: 5,
      fill: false,
      borderWidth: 2,
      data: val });
    ///removendo o inciador que usei
    for (var i = 0; i < this.lineChartDatas.length; i++) {
      if (this.lineChartDatas[i].label == "Exame 01") {
        this.lineChartDatas.splice(i, 1);
      }
    }

   
    console.log("removendo exame");
    console.log(this.lineChartData);
  }

  /*
  exemplo de de remover em array
function removeItemOnce(arr, value) {
  var index = arr.indexOf(value);
  if (index > -1) {
    arr.splice(index, 1);
  }
  return arr;
}

function removeItemAll(arr, value) {
  var i = 0;
  while (i < arr.length) {
    if (arr[i] === value) {
      arr.splice(i, 1);
    } else {
      ++i;
    }
  }
  return arr;
}
// Usage

*/

  
}
